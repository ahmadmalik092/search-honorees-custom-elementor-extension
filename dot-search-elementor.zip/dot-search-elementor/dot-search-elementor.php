<?php
/**
  * Plugin Name: Dot Search Honoree
 * Description: Search Honorees by Name or Branch
 * Version:     1.0.0
 * Author:      M. Ahmad Malik
 * Author URI:  https://www.upwork.com/freelancers/~018baa86584a55223c
 * Text Domain: dot-search-elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main dot-search-elementor Elementor Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Dot_Search_Elementor {

	
	const VERSION = '1.0.0';
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';
	const MINIMUM_PHP_VERSION = '7.0';

	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ] );
	}
	
	
	public function i18n() {

		load_plugin_textdomain( 'dot-search-elementor' );

	}

	
	public function on_plugins_loaded() {

		if ( $this->is_compatible() ) {
			add_action( 'elementor/init', [ $this, 'init' ] );
		}

	}

	
	public function is_compatible() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return false;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return false;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return false;
		}

		return true;

	}

	
	public function init() {
	
		$this->i18n();
		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
		// egister Widget Styles
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );

		// Register Widget Scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		

		
	}

	
	public function init_widgets() {

		// Include Widget files
		require_once( __DIR__ . '/widgets/dot-search-widget.php' );

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Contact_Widget() );

	}

	
	public function init_controls() {

		// Include Control files
		require_once( __DIR__ . '/controls/test-control.php' );

		// Register control
		\Elementor\Plugin::$instance->controls_manager->register_control( 'control-type-', new \Test_Control() );

	}
	
	public function widget_scripts() {
		$plugin_url = plugin_dir_url( __FILE__ );
		wp_enqueue_script( 'hey-single-product-widget-js', $plugin_url.'js/hey_single_product.js',['jquery'],1.0,true );
		
		
	}

	public function widget_styles() {
		$plugin_url = plugin_dir_url( __FILE__ );
		wp_enqueue_style( 'wildix-contact-styles', $plugin_url.'css/wildix-contact.css' );
	}

	
	
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'wildix-contact-elementor' ),
			'<strong>' . esc_html__( 'Wildix Contact Box Addon', 'wildix-contact-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'wildix-contact-elementor' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'wildix-contact-elementor' ),
			'<strong>' . esc_html__( 'Wildix Contact Box Addon', 'wildix-contact-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'wildix-contact-elementor' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'wildix-contact-elementor' ),
			'<strong>' . esc_html__( 'Wildix Contact Box Addon', 'wildix-contact-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'wildix-contact-elementor' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

}

Dot_Search_Elementor::instance();