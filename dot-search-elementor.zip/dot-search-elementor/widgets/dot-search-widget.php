<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
class Contact_Widget extends \Elementor\Widget_Base {


	public function get_name() {
		return 'hey-single-product-elementor';
    }
    
	public function get_title() {
		return __( 'Dot Honoree Search', 'hey-single-product-elementor' );
	}

	public function get_icon() {
		return 'eicon-person';
    }
    
    

	public function get_categories() {
        // Adding Elementor Cateogry
		add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );
		return [ 'hey' ];
    }
    
    function add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'hey',
			[
				'title' => __( 'Hey Addons by Ahmad Malik', 'hey-single-product-elementor' ),
				'icon' => 'fa fa-contact',
			]
		);

	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Search Settings', 'hey-single-product-elementor' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'search_type',
			[
				'label' => __( 'Search Type', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [
					'name'  => __( 'Search by Name', 'plugin-domain' ),
					'branch' => __( 'Search by Branch', 'plugin-domain' )
				],
			]
		);

		$this->add_control(
			'search_msg',
			[
				'label' => __( 'Search Message (Title)', 'hey-single-product-elementor' ),
				'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Click on the first letter of the last name of your honoree',
			]
        );
        
        $this->add_control(
			'show_msg',
			[
				'label' => __( 'Show Message (Title)', 'hey-single-product-elementor' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show Title', 'hey-single-product-elementor' ),
				'label_off' => __( 'Hide Title', 'hey-single-product-elementor' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
        );

		$this->add_control(
			'acf_field_group_key',
			[
				'label' => __( 'Field Group Key', 'hey-single-product-elementor' ),
				'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'group_611aa4e38fb08',
				'placeholder' => 'Key of ACF Field Group to which branch field belongs to...',
			]
        );
        
        $this->add_control(
			'branch_field_key',
			[
				'label' => __( 'Acf Field Key for branch field', 'hey-single-product-elementor' ),
				'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'field_611aa4ff9a810',
				'placeholder' => 'ACF Branch field key',
			]
        );

		$this->end_controls_section();

	}

	protected function render() {

		global $woocommerce;
        //include(plugin_dir_url( __DIR__ ).'../woocommerce-subscribe-all-the-things-master/includes/class-wcs-att-product.php');
        
        
		$settings = $this->get_settings_for_display();
		if($settings['search_type']){
			$search_type = $settings['search_type'];
		}
		else{
			$search_type = 'name';
		}

		
		$show_msg = $settings['show_msg'];
		if($show_msg == 'yes'){
			$search_msg = $settings['search_msg'];
		}else{
			$search_msg = '';
		}

		//$product = wc_get_product( $productId );
		//$image = wp_get_attachment_image_src( get_post_thumbnail_id( $productId ), 'single-post-thumbnail' );
		//$product_attributes = $product->get_attributes();
        
		// if( $product->is_type( 'variable' ) ){
        // 	$variations_raw = $product->get_available_variations();
		// 	$variations = json_encode( $variations_raw );
		// }


		$show_search_by_branch = false;
		$show_search_by_name = false;
		if($search_type == 'branch'){
			$show_search_by_branch = true;	
			$show_search_by_name = false;		
		}else{
			$show_search_by_name = true;
			$show_search_by_branch = false;
		}

		if($show_search_by_name){
			$dot_filters = '<table style="max-width: 400px; text-align: center; margin: 0 auto;"><tr>';
			$i = 0;
			foreach (range('A', 'W') as $char) {
				$dot_filters .= '<td class="dot_name_filter" data-filter="'.$char.'">'.$char.'</td>';
				$i++;
				if(in_array($i, [5,10,15,20])){
					if($i<=20){
						$dot_filters .= '</tr><tr>';
					}
				}
			}
			$dot_filters .= '<td class="dot_name_filter" data-filter="X">X</td><td class="dot_name_filter" data-filter="YZ">Y-Z</td></tr></table>';
			$display_attributes = '<div class="dot_search_filters">'.$dot_filters.'</div>';
		}		

		if($show_search_by_branch){
			$acf_group_key = $settings['acf_field_group_key'];
			$acf_field_key = $settings['branch_field_key']; 
			$fields = acf_get_fields($acf_group_key);
			$dot_filters = '';
			foreach($fields as $field){
				if($field['name']=='branch'){
					foreach($field['choices'] as $choice=>$option){
						$dot_filters .= '<div class="dot_branch_filter" data-filter="'.$option.'" style="text-align:center;">'.$option.'</div>';
					}
				}
			}
			$display_attributes = '<div class="dot_search_filters">'.$dot_filters.'</div>';
		}
		
        $html = '
			<div>
            	<h2 class="hey_product_title">'.$search_msg.'</h2>
            	<div class="display_flex flex-row mb_20">
          
        		</div>
			</div>';
			
	$dot_results = '';
	$args = array(
        'post_type' => 'honorees',
        'posts_per_page' => -1,
		'order' => 'ASC',
    	'orderby' => 'title',
    );
	$query = new WP_Query($args);
	if ($query->have_posts() ) : 
		$dot_results = '<div class="dot_search_results">';
		if($show_search_by_branch){
			$dot_results .= '
				<h3 class="dot_search_title"><span>Army</span> Honorees</h3>
				<p>Click on the Name for Biographical Information on each honoree</p>
			';
		}else{
			$dot_results .= '
				<h3 class="dot_search_title">Honorees</h3>
				<p>Click on the Name for Biographical Information on each honoree</p>
			';
		}
		
		while ( $query->have_posts() ) : $query->the_post();
			
			$branch = get_field( "branch", get_the_ID() );
			$bb = '';
			if(is_array($branch)){
				foreach($branch as $b){
					$bb .= $b;
				}
			}
			$dot_results .= '<div class="dot_result" data-id="' . get_the_ID() . '" data-branch="'.$bb.'" data-name="'.get_the_title().'"><a href="'.esc_url( get_permalink()).'">' . get_the_title() . '</a></div>';
		endwhile;
		$dot_results .= '
			<div class="dot_nav_buttons">
				<button class="dot_go_back">Back</button>
			</div></div>
			';
		wp_reset_postdata();
	endif;

	


		echo '<div class="hey-single-product-box" >';

		echo $html;
		echo $display_attributes;
		echo $dot_results;


		echo '</div>';
		
		?>









<?php
		
		

		
		

    }
    
    protected function _content_template() {
        ?>
        <div class="hey-single-product">
			Enter Product Id first
    	</div>
		
		<?php
	}

}