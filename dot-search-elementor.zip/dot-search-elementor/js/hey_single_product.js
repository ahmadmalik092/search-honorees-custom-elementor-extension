
jQuery(document).ready(function($){

	var $mediaElements = $('.dot_result');

    $('.dot_branch_filter').click(function(e){
        
        e.preventDefault();
        // get the category from the attribute
        var filterVal = $(this).data('filter');

        $('.dot_search_filters').hide();
        $('.dot_search_type').hide();
        $('.hey_product_title').hide();

        $('.dot_search_title span').html(filterVal);

        $('.dot_search_results').show();
        if(filterVal === 'all'){
            $mediaElements.show();
        }else{
        // hide all then filter the ones to show
            $mediaElements.hide().filter('[data-branch="'+filterVal+'"]').show();
        }
    });

    $('.dot_go_back').click(function(e){
        $('.dot_search_filters').show();
        $('.dot_search_type').show();
        $('.hey_product_title').show();
        $('.dot_search_results').hide();
    });

    $('.dot_name_filter').click(function(e){
        var $mediaElements = $('.dot_result');
        e.preventDefault();
        // get the category from the attribute
        var filterVal = $(this).data('filter');

        $('.dot_search_filters').hide();
        $('.dot_search_type').hide();
        $('.hey_product_title').hide();

        $('.dot_search_results').show();
        if(filterVal === 'YZ'){
            $mediaElements.hide().filter(function(){
                return $(this).data('name').toUpperCase()[0] == 'Y' || $(this).data('name').toUpperCase()[0] == 'Z';
             }).show();
        }else{
        // hide all then filter the ones to show
            $mediaElements.hide().filter(function(){
                return $(this).data('name').toUpperCase()[0] == filterVal;
             }).show();
        }
    });
});